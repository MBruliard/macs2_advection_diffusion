To run the program enter in matlab:
advection_diffusion_solver
